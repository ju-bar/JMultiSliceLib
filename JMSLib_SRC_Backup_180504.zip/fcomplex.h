//
// C++ header file: fcomplex.h
// declaration of standard float complex type
//
#pragma once
#include <iostream>
#include <math.h>
#include <complex>
//
// declare basic complex data type
#ifndef FCOMPLEX_H_
#define FCOMPLEX_H_
typedef std::complex<float> fcmplx;
#define J fcmplx(0.F,1.F)
#endif /* FCOMPLEX_H_ */
//

